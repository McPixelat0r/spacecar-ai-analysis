"""
Carpernicus Narrative Generator

This module generates randomized narrative data for space car units, including model names,
sensor suites, telemetry messages, and failure flags, supporting both individual and batch generation.
"""

import random
from faker import Faker
from typing import Dict, List, Optional


class CarpernicusNarrativeGen:
    """
    A generator for creating fictional narrative data related to space cars.

    Attributes:
        fake (Faker): Faker instance for consistent randomization.
        prefixes (List[str]): List of model prefixes.
        tags (List[str]): List of model tags.
        telemetry_messages (List[str]): Sample telemetry logs.
        failure_flags (List[str]): Sample failure messages.
    """

    def __init__(self, seed: Optional[int] = None) -> None:
        """
        Initialize the narrative generator, optionally with a fixed seed for reproducibility.

        Args:
            seed (Optional[int], optional): Random seed for reproducibility. Defaults to None.
        """
        self.fake = Faker()
        if seed is not None:
            random.seed(seed)
            Faker.seed(seed)

        self.prefixes: List[str] = ["Nova", "Void", "Quantum", "Helix", "Luma", "Strato", "Aether", "Vortex"]
        self.tags: List[str] = ["VX-9", "Delta-7", "XR", "Type-3", "Phantom", "Glide", "KX", "Orion"]

        self.telemetry_messages: List[str] = [
            "auto-thrust calibration loop complete",
            "drift correction sequence initiated",
            "gyro lock unstable – heading recalibration needed",
            "core power routing nominal – minimal variance"
        ]

        self.failure_flags: List[str] = [
            "trajectory instability",
            "sensor misalignment",
            "fuel pressure anomaly",
            "course deviation spike"
        ]

    def generate_narrative(self) -> Dict[str, str]:
        """
        Generate a single narrative dictionary containing unit model, sensor suite, telemetry, and failure flag.

        Returns:
            Dict[str, str]: Generated narrative fields.
        """
        unit_model = f"{random.choice(self.prefixes)} {random.choice(self.tags)}"
        sensor_suite = f"OrbitAI S{random.uniform(3.0, 5.0):.1f}"
        last_telemetry = random.choice(self.telemetry_messages)
        failure_flag = random.choice(self.failure_flags)

        return {
            "unit_model": unit_model,
            "sensor_suite": sensor_suite,
            "last_telemetry": last_telemetry,
            "failure_flag": failure_flag
        }

    def generate_batch(self, n: int = 10) -> List[Dict[str, str]]:
        """
        Generate a batch of narrative entries.

        Args:
            n (int, optional): Number of narratives to generate. Defaults to 10.

        Returns:
            List[Dict[str, str]]: List of generated narratives.

        Raises:
            ValueError: If n is negative.
        """
        if not isinstance(n, int) or n < 0:
            raise ValueError("Batch size 'n' must be a non-negative integer.")

        return [self.generate_narrative() for _ in range(n)]
