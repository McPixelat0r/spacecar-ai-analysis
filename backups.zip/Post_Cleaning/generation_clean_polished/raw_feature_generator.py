"""
Raw Feature Generator

This module generates synthetic raw feature data for space cars, including numerical specifications,
component weights, thrust distribution, fuel properties, and sci-fi world elements.
"""

import random
from faker import Faker
from datetime import date
from typing import Dict, Any
import pandas as pd

class RawFeatureGenerator:
    """
    Generator for creating randomized raw feature data entries for simulation and testing.

    Attributes:
        faker (Faker): Faker instance for random names and data.
        car_models (Dict[str, Dict[str, Any]]): Car models mapped to their type and chassis weight.
        engine_weight_range (Dict[str, tuple]): Ranges for engine weights by car type.
        thruster_weight_range (Dict[str, tuple]): Ranges for thruster weights by car type.
        fuel_types (Dict[str, Dict[str, float]]): Fuel types mapped to properties like energy and mass density.
    """

    def __init__(self, seed: int = 42) -> None:
        """
        Initialize the RawFeatureGenerator with a fixed random seed for reproducibility.

        Args:
            seed (int, optional): Random seed. Defaults to 42.
        """
        self.faker = Faker()
        self.faker.seed_instance(seed)
        random.seed(seed)

        self.car_models: Dict[str, Dict[str, Any]] = {
            "Stratos M2": {"car_type": "Sedan", "chassis_weight_kg": 950},
            "Vortex R7": {"car_type": "SUV", "chassis_weight_kg": 1250},
            "Nimbus X1": {"car_type": "Micro", "chassis_weight_kg": 700}
        }

        self.engine_weight_range: Dict[str, tuple] = {
            "Sedan": (180, 260),
            "SUV": (250, 340),
            "Micro": (120, 180)
        }

        self.thruster_weight_range: Dict[str, tuple] = {
            "Sedan": (100, 150),
            "SUV": (140, 200),
            "Micro": (80, 120)
        }

        self.fuel_types: Dict[str, Dict[str, float]] = {
            "IonGel": {"energy_density_MJ_per_kg": 5.2, "mass_density_kg_per_L": 1.1},
            "FusionCore": {"energy_density_MJ_per_kg": 8.4, "mass_density_kg_per_L": 1.6},
            "PlasmaCell": {"energy_density_MJ_per_kg": 6.7, "mass_density_kg_per_L": 1.3}
        }

    def generate_row(self) -> Dict[str, Any]:
        """
        Generate a single randomized feature entry.

        Returns:
            Dict[str, Any]: Dictionary of generated car and trip features.
        """
        car_model = random.choice(list(self.car_models.keys()))
        car_info = self.car_models[car_model]
        car_type = car_info["car_type"]
        chassis_weight = car_info["chassis_weight_kg"]

        moi_values = {
            "Micro": 0.8,
            "Coupe": 1.0,
            "Sedan": 1.2,
            "SUV": 1.5,
            "Transport": 2.0
        }
        moment_of_inertia = moi_values.get(car_type, 1.0)

        engine_weight = random.randint(*self.engine_weight_range[car_type])
        thruster_weight = random.randint(*self.thruster_weight_range[car_type])
        fuel_type = random.choice(list(self.fuel_types.keys()))
        fuel_data = self.fuel_types[fuel_type]
        fuel_weight = random.randint(100, 300)
        starting_fuel_kWh = round(random.uniform(100.0, 300.0), 1)

        total_thrust = round(random.uniform(40.0, 80.0), 1)
        thrust_rear = round(total_thrust * 0.6, 1)
        thrust_front = round(total_thrust * 0.3, 1)
        thrust_side = round(total_thrust * 0.1, 1)

        sci_fi_station_names = [
            "Lunaris Port", "Vega Spire", "Orryx Haven", "Cryon Reach",
            "Zenthar Relay", "Helion Hub", "Cerebra Ring", "Thalos Crossing"
        ]
        sci_fi_admins = [
            "Dr. Calix Renner", "Elia Vorn", "Marshal Keir", "Tamsin Ryx",
            "Axel Orov", "Captain Kael", "Zara Strix", "Commander Yulo"
        ]
        telemetry_templates = [
            "Power levels nominal. Adjusting trajectory.",
            "Fuel low. Navigating around debris.",
            "Re-routing due to unstable path.",
            "Clear path confirmed. Continuing cruise.",
            "Minor vibration detected. Monitoring systems."
        ]

        origin_station = random.choice(sci_fi_station_names)
        destination_station = random.choice([s for s in sci_fi_station_names if s != origin_station])

        return {
            "car_type": car_type,
            "car_model": car_model,
            "chassis_weight_kg": chassis_weight,
            "moment_of_inertia": moment_of_inertia,
            "engine_weight_kg": engine_weight,
            "thruster_weight_kg": thruster_weight,
            "fuel_weight_kg": fuel_weight,
            "starting_fuel_kWh": starting_fuel_kWh,
            "fuel_type": fuel_type,
            "fuel_energy_density_MJ_per_kg": fuel_data["energy_density_MJ_per_kg"],
            "fuel_mass_density_kg_per_L": fuel_data["mass_density_kg_per_L"],
            "total_thrust_kN": total_thrust,
            "thrust_rear_kN": thrust_rear,
            "thrust_front_kN": thrust_front,
            "thrust_side_kN": thrust_side,
            "origin_station": origin_station,
            "destination_station": destination_station,
            "test_admin": random.choice(sci_fi_admins),
            "test_date": date.today().isoformat(),
            "telemetry_message": random.choice(telemetry_templates)
        }

    def export_to_csv(self, output_path: str = "../data/raw_features.csv", n: int = 1000) -> None:
        """
        Generate n rows of features and export them to a CSV file.

        Args:
            output_path (str, optional): Path to save the CSV file. Defaults to '../data/raw_features.csv'.
            n (int, optional): Number of rows to generate. Defaults to 1000.
        """
        if n <= 0:
            raise ValueError("Number of rows 'n' must be a positive integer.")

        data = [self.generate_row() for _ in range(n)]
        df = pd.DataFrame(data)
        df.to_csv(output_path, index=False)
        print(f"✅ Successfully exported {n} rows to '{output_path}'")
